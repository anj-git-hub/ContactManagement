/*package com.spring.ContactManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//@Service
//public class ContactService {
	//private final ContactRepository contactRepository;
	
	//@Autowired
	//public ContactService(ContactRepository contactRepository) {
		this.contactRepository=contactRepository;
	}*/
	//public Contact createContact(Contact contact) {
	//if(contact.getName()==null||contact.getPhoneNumber()==null) {
		//throw new IllegalArgumentException("Name and Phone Number are required.");
	//}
		//return contactRepository.save(contact);
	//}
	//public List<Contact> getAllContacts() {
		//return contactRepository.findAll();
//}
//public Optional<Contact> getContactById(Long id){
	//return contactRepository.findById(id);
//}
//public void deleteContactById(Long id)
//{
	//return contactRepository.deleteById(id);
//}
//public Contact updateContact(Long id,Contact updatedContact) {
	//Optional<Contact> existingContact=contactRepository.findById(id);
	//if(existingContact.isPresent()) {
		//Contact contact = existingContact.get();
		//contact.setName(updatedContact.getName());
		//contact.setAddress(updatedContact.getAddress());
		//contact.setPhoneNumber(updatedContact.getPhoneNumber());
		//contact.setEmail(updatedContact.getEmail());
	//	return contactRepository.save(contact);
	//}
	//else
	//{
		//throw new ContactNotFound Exception("Contact not found with id:"+id);
	//}
//}

	
		
		
	

