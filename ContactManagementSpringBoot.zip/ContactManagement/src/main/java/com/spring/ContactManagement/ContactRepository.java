package com.spring.ContactManagement;

//import org.springframework.stereotype.Repository;

//@Repository
//public class ContactRepository extends JpaRepository<Contact,Long> {

//}
