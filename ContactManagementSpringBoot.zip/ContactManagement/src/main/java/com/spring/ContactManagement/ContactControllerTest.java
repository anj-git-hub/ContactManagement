package com.spring.ContactManagement;
//@RunWith(MockitoJUnitRunner.class)
public class ContactControllerTest {
	//@InjectMocks
	//private ContactController contactController;
	
	//@Mock
	//privateContactRepository contactRepository;
	
	//@Test
	public void testGetAllContacts() {
	}
	
	//@Test
	public void testCreateContact() {
	}
	
	//@Test 
	public void testDeleteContact() {
	}
}

	


